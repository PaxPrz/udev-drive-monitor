# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['udevmonitor']
install_requires = \
['pyudev>=0.22.0,<0.23.0', 'typing>=3.7.4.3,<4.0.0.0']

setup_kwargs = {
    'name': 'udev-usb-monitor',
    'version': '0.1.0',
    'description': 'Monitors usb drive activity (Insertion, Ejection, Moving)',
    'long_description': None,
    'author': 'PaxPrz',
    'author_email': 'paxprajapati@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
